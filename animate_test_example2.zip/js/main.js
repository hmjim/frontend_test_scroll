(function($){
	function getRandomColor() {
	  var letters = '0123456789ABCDEF';
	  var color = '#';
	  for (var i = 0; i < 6; i++) {
		color += letters[Math.floor(Math.random() * 16)];
	  }
	  return color;
	}
	var count = 0;
	var steps = 0;
	$(document).ready(function(){
		$('body').css('height', ($(document).height()*2)*2+'px');
		var lastScrollTop = 0;
		$(window).scroll(function(event){

		   var st = $(this).scrollTop();
		   
		   if (st > lastScrollTop){

			   if(lastScrollTop > steps){
			   count++;
			   steps=steps+$(document).height()/ 12;
			   $('#holder').attr('class', 'step'+count);
			   $('#bubble').attr('class', 'step'+count);
			   $('#bubble').css('background', getRandomColor());
			   $('#bubble').css('border-bottom-color', getRandomColor());				
			   }
			   // console.log(lastScrollTop+" : "+steps);
		   } else {
			   if(lastScrollTop < steps){
			   count--;
			   steps=steps-$(document).height()/ 12;
			   $('#holder').attr('class', 'step'+count);
			   $('#bubble').attr('class', 'step'+count);
			   $('#bubble').css('background', getRandomColor());
			   $('#bubble').css('border-bottom-color', getRandomColor());
			   }
			   // console.log(lastScrollTop+" : "+steps);			  
		   }
		   lastScrollTop = st;
		});
	});
})(jQuery);